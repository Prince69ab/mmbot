import discord
from discord.ext import commands
import json

class infar(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    
    def load_autoresponders(self):
        with open('autoresponder.json', 'r') as f:
            return json.load(f)

    
    def save_autoresponders(self, autoresponders):
        with open('autoresponder.json', 'w') as f:
            json.dump(autoresponders, f)
            
    admin = 1125461447686766612          

    @commands.command()
    @commands.has_role(admin) 
    async def addar(self, ctx, keyword=None, *, response=None):
        autoresponders = self.load_autoresponders()
        if keyword and response:
            autoresponders[keyword.lower()] = response
            self.save_autoresponders(autoresponders)

            embed = discord.Embed(
                description=f'AR set for "{keyword}"',
                color=0xc807cf
            )

            await ctx.send(embed=embed)
        else:
            await ctx.send('Please provide a keyword and a response')                 

    @commands.command()
    @commands.has_role(admin) 
    async def listar(self, ctx):
        autoresponders = self.load_autoresponders()
        if autoresponders:
            embed = discord.Embed(title="Trusted Service ARs", color=0xc807cf)
            for keyword, response in autoresponders.items():
                embed.add_field(name=f"Keyword: {keyword}", value=f"Response: {response}", inline=False)
            await ctx.send(embed=embed)
        else:
            await ctx.send('No ARs set')

    @commands.command()
    @commands.has_role(admin) 
    async def delar(self, ctx, keyword=None):
        autoresponders = self.load_autoresponders()
        if keyword:
            if keyword.lower() in autoresponders:
                del autoresponders[keyword.lower()]
                self.save_autoresponders(autoresponders)
                embed = discord.Embed(
                    description=f'AR removed for "{keyword}"',
                    color=0xc807cf
                )

                await ctx.send(embed=embed)
            else:
                await ctx.send(f'No AR found for "{keyword}"')
        else:
            await ctx.send('Please provide a keyword')

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author == self.bot.user:
            return

        mm = [1125461447686766612]

        member_roles = [role.id for role in message.author.roles]
        has_mm_role = any(role_id in member_roles for role_id in mm)

        if has_mm_role:
            autoresponders = self.load_autoresponders()
            for keyword, response in autoresponders.items():
                if keyword in message.content.lower():
                    await message.delete()
                    await message.channel.send(response)

def setup(bot):
    bot.add_cog(infar(bot))