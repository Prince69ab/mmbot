import discord
from discord.ext import commands, tasks

import json

class infnn(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.saved_nicknames = {}

        try:
            with open("saved_nicknames.json", "r") as f:
                self.saved_nicknames = json.load(f)
        except FileNotFoundError:
            pass

        self.sync_nicknames.start()

    def save_nicknames(self):
        with open("saved_nicknames.json", "w") as f:
            json.dump(self.saved_nicknames, f)

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def save(self, ctx, user: discord.User, *, nickname: str):
        self.saved_nicknames[str(user.id)] = nickname
        self.save_nicknames()
        await ctx.send(f"NN for {user.mention} has been saved as '{nickname}'")

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def syncnn(self, ctx):
        for member in ctx.guild.members:
            user_id = str(member.id)
            if user_id in self.saved_nicknames:
                nickname = self.saved_nicknames[user_id]
                try:
                    await member.edit(nick=nickname)
                except discord.Forbidden:
                    pass
        await ctx.send("Sync completed")

    @tasks.loop(hours=1)
    async def sync_nicknames(self):
        for guild in self.bot.guilds:
            for member in guild.members:
                user_id = str(member.id)
                if user_id in self.saved_nicknames:
                    nickname = self.saved_nicknames[user_id]
                    try:
                        await member.edit(nick=nickname)
                    except discord.Forbidden:
                        pass

    @sync_nicknames.before_loop
    async def before_sync_nicknames(self):
        await self.bot.wait_until_ready()

    @commands.Cog.listener()
    async def on_member_join(self, member):
        user_id = str(member.id)
        if user_id in self.saved_nicknames:
            nickname = self.saved_nicknames[user_id]
            try:
                await member.edit(nick=nickname)
            except discord.Forbidden:
                pass
def setup(bot):
    bot.add_cog(infnn(bot))