import discord
from discord.ext import commands

class infextra(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def say(self, ctx, *, message):
        await ctx.message.delete()  
        await ctx.send(message) 

    @say.error
    async def say_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("unauthorized")
            
            from discord.ext import commands

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def embed(self, ctx):

        await ctx.send('Type out for embed')

        await ctx.reply('Title')
        title_msg = await self.bot.wait_for('message', check=lambda m: m.author == ctx.author and m.channel == ctx.channel, timeout=30)
        title = title_msg.content

        await ctx.reply('Descr')
        description_msg = await self.bot.wait_for('message', check=lambda m: m.author == ctx.author and m.channel == ctx.channel, timeout=30)
        description = description_msg.content

        await ctx.reply('Color (#FF0000)')
        color_msg = await self.bot.wait_for('message', check=lambda m: m.author == ctx.author and m.channel == ctx.channel, timeout=30)
        color = color_msg.content.strip('#')
        try:
            embed_color = discord.Color(int(color, 16))
        except ValueError:
            await ctx.reply('Invalid color provided Using default color')
            embed_color = discord.Color.default()

        await ctx.reply('Footer, Type 0 to skip')
        footer_msg = await self.bot.wait_for('message', check=lambda m: m.author == ctx.author and m.channel == ctx.channel, timeout=30)
        footer = footer_msg.content if footer_msg.content != '0' else None

        await ctx.reply('Thumb, Type 0 to skip')
        thumbnail_msg = await self.bot.wait_for('message', check=lambda m: m.author == ctx.author and m.channel == ctx.channel, timeout=30)
        thumbnail = thumbnail_msg.content if thumbnail_msg.content != '0' else None

        image_msg = await self.bot.wait_for('message', check=lambda m: m.author == ctx.author and m.channel == ctx.channel, timeout=30)
        image = image_msg.content if image_msg.content != '0' else None

        await ctx.reply('Channelid')
        channel_id_msg = await self.bot.wait_for('message', check=lambda m: m.author == ctx.author and m.channel == ctx.channel, timeout=30)
        try:
            channel_id = int(channel_id_msg.content)
        except ValueError:
            await ctx.reply("Invalid channel ID Please enter a numerical value.")
            return

        channel = self.bot.get_channel(channel_id)
        if not channel:
            await ctx.reply(f'Invalid channel ID: {channel_id}')
            return

        embed = discord.Embed(title=title, description=description, color=embed_color)
        if footer:
            embed.set_footer(text=footer)
        if thumbnail:
            embed.set_thumbnail(url=thumbnail)
        if image:
            embed.set_image(url=image)

        try:
            await channel.send(embed=embed)
            await ctx.reply('Embed sent')
        except Exception as e:
            await ctx.reply(f'Error sending embed: {e}')
            
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def calc(self, ctx, *, expression):
        try:
            result = eval(expression)
            embed = discord.Embed(
                title="Calculator",
                description=f"``{expression}``\n``{result}``",
                color=0xc807cf
            )
        except Exception as e:
            embed = discord.Embed(
                title="Calc",
                description=f"error on invalid expression:\n```{e}```",
                color=0xc807cf
            )

        await ctx.reply(embed=embed)

def setup(bot):
    bot.add_cog(infextra(bot))