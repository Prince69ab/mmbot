import discord
import json
from discord.ext import commands

# put restrict role id in line 41

class infmm(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.access_roles = access_roles 
        self.client_role_id = client_role_id  

    @commands.command()
    async def rcv(self, ctx, *, message):
        if any(role.id in self.access_roles for role in ctx.author.roles):
            embed = discord.Embed(
                description=f"**<@{ctx.author.id}> Received ``{message}``\nNow you can continue your deal \nPing {ctx.author.mention} for releasing the funds**",
                color=0xc807cf
            )
            embed.set_footer(text="Prime Service", icon_url="https://cdn.discordapp.com/attachments/1121351794409361487/1135685778266148904/image.png")
            await ctx.send(embed=embed)

            
            await ctx.message.delete()
            
    @commands.command()
    async def client(self, ctx, user: discord.Member):
        if any(role.id in self.access_roles for role in ctx.author.roles):
            client_role = ctx.guild.get_role(self.client_role_id)
            await user.add_roles(client_role)
            
            embed = discord.Embed(
                description=f"**Client has been given to {user.mention}**",
                color=0xc807cf
            )
            embed.set_footer(text="Prime Service", icon_url="https://cdn.discordapp.com/attachments/1121351794409361487/1135685778266148904/image.png")
            await ctx.send(embed=embed)
            await ctx.message.delete()   

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def restrict(self, ctx, member: discord.Member):
        restrict_role_id = # 
        
        await member.edit(roles=[])
        
        restrict_role = discord.utils.get(ctx.guild.roles, id=restrict_role_id)
        await member.add_roles(restrict_role)
        
        embed = discord.Embed(
            title='User Restricted',
            description=f'{member.mention} has been restricted.',
            color=0xc807cf
        )
        embed.set_thumbnail(url=member.avatar_url)
        embed.set_footer(text=f'Restricted by {ctx.author.name}', icon_url=ctx.author.avatar_url)
        
        await ctx.send(embed=embed)

    @restrict.error
    async def restrict_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send('unathorised')
        elif isinstance(error, commands.MemberNotFound):
            await ctx.send('Member not found')
        else:
            await ctx.send('error')            
            
def setup(bot):
    bot.add_cog(infmm(bot))