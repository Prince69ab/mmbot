import discord
from discord.ext import commands
import json
import random
from datetime import datetime

class infectedwarn(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_data(self):
        try:
            with open('warns.json', 'r') as file:
                return json.load(file)
        except FileNotFoundError:
            return {}

    def save_data(self, data):
        with open('warns.json', 'w') as file:
            json.dump(data, file, indent=4)

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def warn(self, ctx, member: discord.Member, *, reason):
        data = self.load_data()

        member_id = str(member.id)
        if member_id not in data:
            data[member_id] = []

        tag = f'{random.randint(10, 9999)}'
        while tag in [warn["tag"] for warn in data[member_id]]:
            tag = f'{random.randint(10, 9999)}'

        data[member_id].append({"tag": tag, "reason": reason})
        self.save_data(data)

        logging_channel_id = 1125309049307660319
        logging_channel = self.bot.get_channel(logging_channel_id)
        if logging_channel:
            embed = discord.Embed(
                title="**__User has been Warned__**",
                color=0xc807cf
            )
            embed.add_field(name="**User**", value=f"``{member.name} ({member.id})``", inline=True)
            embed.add_field(name="**Mod**", value=f"``{ctx.author.name} ({ctx.author.id})``", inline=True)
            embed.add_field(name="**Reason**", value=f"``{reason}``", inline=True)
            embed.add_field(name="**Warn ID**", value=f"``{tag}``", inline=False)
            await logging_channel.send(embed=embed)

        reply_embed = discord.Embed(
            title="**__User has been Warned__**",
            color=0xc807cf
        )
        reply_embed.add_field(name="**User**", value=f"``{member.name} ({member.id})``", inline=True)
        reply_embed.add_field(name="**Mod**", value=f"``{ctx.author.name} ({ctx.author.id})``", inline=True)
        reply_embed.add_field(name="**Reason**", value=f"``{reason}``", inline=True)
        reply_embed.add_field(name="**Warn ID**", value=f"``{tag}``", inline=False)
        await ctx.send(embed=reply_embed)
            
    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def revoke(self, ctx, tag: str):
        data = self.load_data()

        for member_id, warns in data.items():
            for warn in warns:
                if warn["tag"] == tag:
                    warns.remove(warn)
                    self.save_data(data)

                    embed = discord.Embed(
                        description=f"The warn with Warn ID ``{tag}`` has been revoked",
                        color=0xc807cf
                    )
                    await ctx.reply(embed=embed)
                    return

        embed = discord.Embed(
            description=f"No warn found with tag `{tag}`.",
            color=0xc807cf
        )
        await ctx.reply(embed=embed)

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def reset(self, ctx, member: discord.Member):
        data = self.load_data()

        member_id = str(member.id)
        if member_id in data:
            del data[member_id]
            self.save_data(data)

            embed = discord.Embed(
                description=f"All warns for {member.mention} have been reset",
                color=0xc807cf
            )
            await ctx.reply(embed=embed)
        else:
            embed = discord.Embed(
                description=f"{member.mention} has no warns",
                color=0xc807cf
            )
            await ctx.reply(embed=embed)


    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def transfer(self, ctx, member1: discord.Member, member2: discord.Member):
        data = self.load_data()

        member1_id = str(member1.id)
        if member1_id in data:
            warns = data[member1_id]
            member2_id = str(member2.id)

            if member2_id not in data:
                data[member2_id] = []

            data[member2_id].extend(warns)
            del data[member1_id]
            self.save_data(data)
            
            embed = discord.Embed(
                description=f"Transferred all datas from {member1.mention} to {member2.mention}",
                color=0xc807cf
            )
            await ctx.reply(embed=embed)
        else:
            embed = discord.Embed(
                description=f"{member1.mention} has no warns",
                color=0xc807cf
            )
            await ctx.reply(embed=embed)
            
            
    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def profile(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        data = self.load_data()

        member_id = str(member.id)
        if member_id in data:
            warns = data[member_id]
            embed = discord.Embed(
                title=f"{member.display_name}'s Profile",
                description=f"**Warns:** {len(warns)}",
                color=0xc807cf
            )

            for idx, warn in enumerate(warns, start=1):
                embed.add_field(name=f"Warn {idx} - {warn['tag']}", value=f"Reason: {warn['reason']}", inline=False)

        else:
            embed = discord.Embed(
                title=f"{member.display_name}'s Profile",
                description="**Warns:** None",
                color=0xc807cf
            )

        join_timestamp = member.joined_at.timestamp()
        join_formatted = f"<t:{int(join_timestamp)}:R>"
        embed.add_field(name="Server Joined", value=join_formatted, inline=False)
        roles = [role.mention for role in member.roles if role != ctx.guild.default_role]
        if roles:
            roles_string = " ".join(roles)
            embed.add_field(name="Roles", value=roles_string, inline=False)
        else:
            embed.add_field(name="Roles", value="No roles", inline=False)

        await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(infectedwarn(bot))