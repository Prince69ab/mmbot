import discord
from discord.ext import commands
import os
import datetime


class infmod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.deleted_messages = {}
        self.edited_messages = {}

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.channel.id not in self.deleted_messages:
            self.deleted_messages[message.channel.id] = []
        self.deleted_messages[message.channel.id].append(message)

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if before.channel.id not in self.edited_messages:
            self.edited_messages[before.channel.id] = []
        self.edited_messages[before.channel.id].append((before, after))

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def snipe(self, ctx):
        channel = ctx.channel
        if channel.id in self.deleted_messages and len(self.deleted_messages[channel.id]) > 0:
            msg = self.deleted_messages[channel.id].pop()
    
            embed = discord.Embed(
                title="Sniped Msg",
                color=0xc807cf
            )
            embed.add_field(name="Content", value=msg.content, inline=False)
            embed.add_field(name="User", value=msg.author.mention, inline=False)
    
            await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def snipeall(self, ctx):
        channel = ctx.channel
        if channel.id in self.deleted_messages and len(self.deleted_messages[channel.id]) > 0:
            while self.deleted_messages[channel.id]:
                msg = self.deleted_messages[channel.id].pop()
                embed = discord.Embed(
                    title="Sniped Msgs",
                    color=0xc807cf
                )
                embed.add_field(name="Content", value=msg.content)
                embed.add_field(name="User", value=msg.author.mention)
                embed.add_field(name="Channel", value=channel.mention)
                await ctx.reply(embed=embed)

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def editsnipe(self, ctx):
        channel = ctx.channel
        
        if channel.id in self.edited_messages and len(self.edited_messages[channel.id]) > 0:
            before, after = self.edited_messages[channel.id].pop()
            
            embed = discord.Embed(title="Sniped Edit Message", color=0xc807cf)
            embed.add_field(name="Old Msg", value=before.content, inline=False)
            embed.add_field(name="User", value=before.author.mention, inline=False)
            embed.add_field(name="New Msg", value=after.content, inline=False)
            
            await ctx.reply(embed=embed)
        else:
            await ctx.reply("No edited msg found")

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def editsnipeall(self, ctx):
        channel = ctx.channel
        
        if channel.id in self.edited_messages and len(self.edited_messages[channel.id]) > 0:
            while self.edited_messages[channel.id]:
                before, after = self.edited_messages[channel.id].pop()
                
                embed = discord.Embed(title="Sniped All Edit Messages", color=0xc807cf)
                embed.add_field(name="Old Msg", value=before.content, inline=False)
                embed.add_field(name="User", value=before.author.mention, inline=False)
                embed.add_field(name="New msges", value=after.content, inline=False)
                
                await ctx.reply(embed=embed)
        else:
            await ctx.reply("No edited msges found")

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def ban(self, ctx, member: discord.Member, *, reason=None):
        await member.ban(reason=reason)
        
        embed = discord.Embed(title="User Banned", color=0xc807cf)
        embed.set_thumbnail(url=member.avatar_url)
        embed.add_field(name="Banned User", value=f"{member} ({member.id})", inline=False)
        embed.add_field(name="Reason", value=reason if reason else "No reason provided", inline=False)
        embed.set_footer(text=f"Banned by {ctx.author} ({ctx.author.id})", icon_url=ctx.author.avatar_url)
    
        await ctx.reply(embed=embed)

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def unban(self, ctx, *, member_id: int):
        banned_users = await ctx.guild.bans()
        for ban_entry in banned_users:
            user = ban_entry.user
            if user.id == member_id:
                await ctx.guild.unban(user)
                
                embed = discord.Embed(title="User Unbanned", color=0xc807cf)
                embed.set_thumbnail(url=user.avatar_url)
                embed.add_field(name="Unbanned User", value=f"{user} ({user.id})", inline=False)
                embed.set_footer(text=f"Unbanned by {ctx.author} ({ctx.author.id})", icon_url=ctx.author.avatar_url)
                
                await ctx.reply(embed=embed)
                return
        
        await ctx.reply('User not found.')

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def kick(self, ctx, member: discord.Member, *, reason=None):
        await member.kick(reason=reason)
        
        embed = discord.Embed(title="User Kicked", color=0xc807cf)
        embed.set_thumbnail(url=member.avatar_url)
        embed.add_field(name="Kicked User", value=f"{member} ({member.id})", inline=False)
        embed.add_field(name="Reason", value=reason if reason else "No reason provided", inline=False)
        embed.set_footer(text=f"Kicked by {ctx.author} ({ctx.author.id})", icon_url=ctx.author.avatar_url)
        
        await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(infmod(bot))