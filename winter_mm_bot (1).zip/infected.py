import discord
from discord.ext import commands
import os
import time
from colorama import Fore, Style

infected = ''

intents = discord.Intents.default()
intents.typing = True
intents.presences = True

bot = commands.Bot(command_prefix='-', intents=intents, help_command=None)
    
@bot.command(aliases=['h'])
async def help(ctx):
    command_list = bot.commands
    sorted_commands = sorted(command_list, key=lambda x: x.name)

    response = "**Prime Service**\n\n"
    for command in sorted_commands:
        if await command.can_run(ctx):
            response += f"_{command.name}_, "

    await ctx.reply(response)

    
@bot.event
async def on_ready():
    print(f'{Fore.MAGENTA}{Style.BRIGHT}-------------------------------')
    print(f'{Fore.MAGENTA}{Style.BRIGHT}        X Clouds | Hosting Bot Connected')
    print(f'{Fore.MAGENTA}{Style.BRIGHT}-------------------------------')
    print(f'{Fore.LIGHTMAGENTA_EX}{Style.BRIGHT}Name: {bot.user.name}')
    print(f'{Fore.LIGHTMAGENTA_EX}{Style.BRIGHT}Developer: I N F E C T E D')
    print(f'{Fore.LIGHTMAGENTA_EX}{Style.BRIGHT}Version: Winter')
    print(f'{Fore.LIGHTMAGENTA_EX}{Style.BRIGHT}Server: https://discord.gg/xclouds')
    print(f'{Fore.MAGENTA}{Style.BRIGHT}-------------------------------{Style.RESET_ALL}')
    for filename in os.listdir('./cogs'):
        if filename.endswith('.py'):
            bot.load_extension(f'cogs.{filename[:-3]}')


bot.run(infected)